from django.apps import AppConfig


class JerryConfig(AppConfig):
    name = 'jerry'
